import { Component, } from '@angular/core';
import * as HighCharts from 'highcharts';



@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  title = 'incident by age';
  type = 'PieChart';
  data = [
    ['upto 3 days', 85],
    ['4 to 7 days', 1049],
    ['8 to 14 days', 1248],
    ['over 2 weeks', 819],

  ];
  columnNames = ['Browser', 'Percentage'];
  options = {
    is3D: true,
    legend: { position: 'bottom' },
    // pieStartAngle: 135,
    // pieSliceText: 'label'

  };
  width = 850;
  height = 470;

}
