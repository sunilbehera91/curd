import { Injectable } from '@angular/core';
 import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class IssueService {
uri="http://localhost:4000";

  constructor( private http:HttpClient) { }
   getIssues(){
   	return this.http.get('http://localhost:4000/issues');
   	
   }
   getIssueById(id){
   	return this.http.get('http://localhost:4000/issues/'+id);
   
   }
   addIssue(title,responsible,decription,severity){
   	const issue={
     title:title,
     responsible:responsible,
     decription:decription,
     severity:severity
     //status:status, 
   	};
   	return this.http.post('http://localhost:4000/issues/add',issue);

   }
   updateIssue(id,title,responsible,decription,severity,status){
   	const issue={
     title:title,
     responsible:responsible,
     decription:decription,
     severity:severity,
     status:status 
   	};
   	return this.http.post('http://localhost:4000/issues/update/'+id,issue);

   }
     deleteIssue(id){
     
   	return this.http.get('http://localhost:4000/issues/delete/'+id);
   
   }
}
