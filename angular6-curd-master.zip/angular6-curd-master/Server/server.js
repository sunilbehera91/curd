
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import Issue from './models/issue';
const path =require('path');
const app =express();
const router =express.Router();
app.use(cors());
app.use(bodyParser.json()); 

mongoose.connect('mongodb://main:main123@ds147011.mlab.com:47011/demodatabse');
const connection =mongoose.connection;
connection.once('open',() =>{
	console.log("mongoosecoonct");

});
router.route('/issues').get((req,res)=>{
	Issue.find((err,issues)=>{
		if(err){
			console.log(err);
		}
		else{
			res.json(issues);
		}
	});
});
router.route('/issues/:id').get((req,res)=>{
	Issue.findById(req.params.id ,(err,issue)=>{
		if(err)
			console.log(err);
         else
			res.json(issue)
		});
	
})
router.route('/issues/add').post((req,res)=>{
	let issue = new Issue(req.body);
 issue.save()
 	.then(issue =>{
 		res.status(200).json({'issue':'added Sucessfully'});

 	})
   .catch(err =>{
   	res.status(400).send('Failed To create new record');
   });
}) ;

router.route('/issues/update/:id').post((req,res)=>{
	Issue.findById(req.params.id,(err,issue)=>{
		if(!issue)
			return next(new Error('Coud Not Load Document'));
			else{
				issue.title=req.body.title;
				issue.responsible=req.body.responsible;
				issue.decription=req.body.severity;
				issue.severity=req.body.severity;
				issue.status=req.body.status;
				issue.save().then(issue=>{
			    	res.json('updated Done');

			    }).catch(err =>{
			    	res.status(400).send('Updated Failed');
			    });
		}
	});
});


router.route('/issues/delete/:id').get((req,res)=>{
	Issue.findByIdAndRemove({_id:req.params.id},(err,issue)=>{
		if(err)
			res.json(err);
		else
			res.json('Remove SucessFully');
	})
})
app.use('/',router);

//app.get('/',(req,res) => res.send('Hello World'));

app.use(express.static(__dirname + 'dist/angular6curd'));
console.log("ddd");
console.log(__dirname+'/dist/angular6curd');
app.get('/*',(req,res)=>res.sendFile(path.join(__dirname)));
app.listen (3001,() => console.log('Express Server Running on the port 3001'));
